Iconset: Eon - Social Media & Contact Info (https://www.iconfinder.com/iconsets/eon-social-media-contact-info-2)
Author: Bombasticon Studio (https://www.iconfinder.com/bombasticon)
License: Free for commercial use ()
Download date: 2022-05-15